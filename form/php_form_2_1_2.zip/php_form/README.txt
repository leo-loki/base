## /* ++++++++++ PHP form system ++++++++++ */

# Original PHP form system (ver.2.1.2)

// author  : Loki.（https://github.com/leo-loki）

// website : https://www.i-studio.jp/

***


このプログラムはPHPを利用した簡易メール送信フォームです。  
入力項目を修正することで、「お問合せ」や「お申込み」フォームとしてご利用いただけます。


### 【ダウンロードと詳細はこちら】

https://github.com/leo-loki/base/tree/master/form


### 【動作サンプルはこちら】

https://www.i-studio.jp/php_form/


